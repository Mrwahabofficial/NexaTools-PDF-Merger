============================================================
  PDF Merger Pro — NexaTools
  Combine multiple PDF files into one in seconds
============================================================

  Before you start, make sure Python is installed.
  Download it free at python.org
  
  During installation, check the box that says
  "Add Python to PATH" — this is important!

------------------------------------------------------------
  HOW TO RUN
------------------------------------------------------------

  1. Open this folder
  2. Click the address bar at the top
  3. Type "cmd" and press Enter
  4. In the terminal, type:

        python pdf_merger.py

  5. Press Enter and the tool will start

------------------------------------------------------------
  MERGING YOUR FILES
------------------------------------------------------------

  The tool gives you two ways to merge:

  Option 1 — Select files one by one
  
    Perfect when you have a few specific PDFs to merge.
    
    To get a file path:
    - Find your PDF file
    - Right click on it
    - Click "Copy as path"
    - Paste it in the terminal with Ctrl+V
    - Press Enter
    - Repeat for each file
    - When done, just press Enter on an empty line

  Option 2 — Select an entire folder
  
    Perfect when all your PDFs are in one folder.
    
    - Right click on the folder
    - Click "Copy as path"
    - Paste it in the terminal
    - Press Enter
    - The tool finds all PDFs automatically

------------------------------------------------------------
  NAMING YOUR OUTPUT FILE
------------------------------------------------------------

  After selecting your files, you will be asked:

    Output filename [merged_output.pdf]:

  You can type your own name like "report_final"
  or just press Enter to use the default name.

------------------------------------------------------------
  CONFIRMING THE MERGE
------------------------------------------------------------

  You will see a preview of your files:

    1. document1.pdf
    2. document2.pdf
    Output: merged_output.pdf

    Proceed? (yes/no):

  Type "yes" and press Enter to start merging.

------------------------------------------------------------
  WHERE IS MY MERGED FILE?
------------------------------------------------------------

  Once complete, you will see:

    Merge Complete!
    Files merged  : 2
    Total pages   : 6
    Output file   : merged_output.pdf

  The merged PDF is saved in the same folder
  where you ran the script from.

  Just double click it to open!

------------------------------------------------------------
  TROUBLESHOOTING
------------------------------------------------------------

  Python not found
    Download and install Python from python.org
    Make sure to check "Add Python to PATH"

  File not found
    Use Right Click then Copy as path
    to get the correct file path

  File is not a PDF
    Only .pdf files are supported

  Stream ended unexpectedly
    Your PDF may be corrupted
    Try recreating it by printing to PDF
    from Word or Notepad

------------------------------------------------------------
  SUPPORT
------------------------------------------------------------

  Visit us at payhip.com/NexaDevTools

  NexaTools — Next Generation Developer Tools
============================================================
